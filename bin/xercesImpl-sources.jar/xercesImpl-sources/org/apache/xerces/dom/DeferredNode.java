/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.xerces.dom;

import org.w3c.dom.Node;

/** 
 * An interface for deferred node object.
 * 
 * @xerces.internal
 *
 * @version $Id: DeferredNode.java 447266 2006-09-18 05:57:49Z mrglavas $
 */
public interface DeferredNode extends Node {


     public static final short TYPE_NODE  =  20;

    //
    // DeferredNode methods
    //

    /** Returns the node index. */
    public int getNodeIndex();

} // interface DeferredNode
